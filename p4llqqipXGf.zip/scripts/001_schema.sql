-- AcolheApp — esquema PostgreSQL (Neon / Supabase)
-- Todo acesso a dados clínicos deve ser filtrado por therapist_id (multi-tenant).

create extension if not exists "pgcrypto";

-- Profissionais (usuários do SaaS)
create table therapists (
  id            uuid primary key default gen_random_uuid(),
  name          text not null,
  email         text not null unique,
  crp           text,
  approach      text,
  created_at    timestamptz not null default now()
);

-- Assinatura e controle de acesso (trial, inadimplência)
create type subscription_status as enum ('trialing', 'active', 'past_due', 'canceled', 'expired');
create type billing_provider as enum ('stripe', 'asaas');

create table subscriptions (
  id                      uuid primary key default gen_random_uuid(),
  therapist_id            uuid not null unique references therapists(id) on delete cascade,
  plan                    text not null default 'trial' check (plan in ('trial', 'essencial', 'profissional')),
  status                  subscription_status not null default 'trialing',
  trial_ends_at           timestamptz not null default now() + interval '7 days',
  current_period_end      timestamptz,
  past_due_since          timestamptz,
  records_created         integer not null default 0,
  provider                billing_provider,
  provider_customer_id    text,
  provider_subscription_id text unique,
  cancel_at_period_end    boolean not null default false,
  updated_at              timestamptz not null default now()
);

create table invoices (
  id                  uuid primary key default gen_random_uuid(),
  therapist_id        uuid not null references therapists(id) on delete cascade,
  provider            billing_provider not null,
  provider_invoice_id text not null unique,
  amount_cents        integer not null check (amount_cents >= 0),
  status              text not null check (status in ('pago', 'pendente', 'atrasado', 'estornado')),
  pdf_url             text,
  due_date            date not null,
  paid_at             timestamptz,
  created_at          timestamptz not null default now()
);

-- Idempotência de webhooks (Stripe / Asaas)
create table billing_events (
  id           text primary key,
  provider     billing_provider not null,
  type         text not null,
  payload      jsonb not null,
  processed_at timestamptz not null default now()
);

-- Pacientes
create table patients (
  id            uuid primary key default gen_random_uuid(),
  therapist_id  uuid not null references therapists(id) on delete cascade,
  name          text not null,
  email         text,
  phone         text,
  birth_date    date,
  session_fee_cents integer not null default 0,
  approach      text,
  consent_recording_at timestamptz,
  archived_at   timestamptz,
  created_at    timestamptz not null default now()
);
create index patients_therapist_idx on patients(therapist_id);

-- Agenda (com sincronização Google Calendar)
create table appointments (
  id               uuid primary key default gen_random_uuid(),
  therapist_id     uuid not null references therapists(id) on delete cascade,
  patient_id       uuid not null references patients(id) on delete cascade,
  starts_at        timestamptz not null,
  ends_at          timestamptz not null,
  modality         text not null check (modality in ('presencial', 'online')),
  status           text not null default 'pendente' check (status in ('confirmado', 'pendente', 'cancelado', 'realizado')),
  google_event_id  text,
  google_etag      text,
  created_at       timestamptz not null default now(),
  check (ends_at > starts_at)
);
create index appointments_therapist_time_idx on appointments(therapist_id, starts_at);
create unique index appointments_google_event_idx on appointments(therapist_id, google_event_id) where google_event_id is not null;

create table calendar_connections (
  therapist_id     uuid primary key references therapists(id) on delete cascade,
  google_email     text not null,
  refresh_token_enc bytea not null,
  calendar_id      text not null default 'primary',
  sync_token       text,
  channel_id       text,
  channel_expires_at timestamptz,
  updated_at       timestamptz not null default now()
);

-- Sessões e prontuários
create table sessions (
  id              uuid primary key default gen_random_uuid(),
  therapist_id    uuid not null references therapists(id) on delete cascade,
  patient_id      uuid not null references patients(id) on delete cascade,
  appointment_id  uuid references appointments(id) on delete set null,
  started_at      timestamptz not null default now(),
  ended_at        timestamptz,
  transcript_enc  bytea, -- transcrição criptografada (pgp_sym_encrypt); áudio nunca é armazenado
  created_at      timestamptz not null default now()
);

create table clinical_records (
  id            uuid primary key default gen_random_uuid(),
  therapist_id  uuid not null references therapists(id) on delete cascade,
  patient_id    uuid not null references patients(id) on delete cascade,
  session_id    uuid unique references sessions(id) on delete set null,
  objetivo      text not null default '',
  avaliacao     text not null default '',
  conduta       text not null default '',
  ai_generated  boolean not null default true,
  signed_at     timestamptz,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);
create index clinical_records_patient_idx on clinical_records(therapist_id, patient_id, created_at desc);

create table copilot_insights (
  id          uuid primary key default gen_random_uuid(),
  session_id  uuid not null references sessions(id) on delete cascade,
  type        text not null check (type in ('alerta', 'padrao', 'sugestao', 'pergunta')),
  content     text not null,
  created_at  timestamptz not null default now()
);

-- Sophia (supervisão com IA)
create table sophia_conversations (
  id            uuid primary key default gen_random_uuid(),
  therapist_id  uuid not null references therapists(id) on delete cascade,
  title         text,
  created_at    timestamptz not null default now()
);

create table sophia_messages (
  id              uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references sophia_conversations(id) on delete cascade,
  role            text not null check (role in ('user', 'assistant')),
  parts           jsonb not null,
  created_at      timestamptz not null default now()
);

-- Financeiro
create table payments (
  id            uuid primary key default gen_random_uuid(),
  therapist_id  uuid not null references therapists(id) on delete cascade,
  patient_id    uuid not null references patients(id) on delete cascade,
  appointment_id uuid references appointments(id) on delete set null,
  description   text not null,
  amount_cents  integer not null check (amount_cents > 0),
  method        text not null check (method in ('PIX', 'Cartão', 'Dinheiro', 'Transferência')),
  status        text not null default 'pendente' check (status in ('pago', 'pendente', 'atrasado')),
  due_date      date not null,
  paid_at       timestamptz,
  created_at    timestamptz not null default now()
);
create index payments_therapist_status_idx on payments(therapist_id, status, due_date);

create table receipts (
  id            uuid primary key default gen_random_uuid(),
  therapist_id  uuid not null references therapists(id) on delete cascade,
  payment_id    uuid not null unique references payments(id) on delete cascade,
  number        text not null,
  issued_at     timestamptz not null default now(),
  unique (therapist_id, number)
);

-- Trilha de auditoria (LGPD: quem acessou/alterou dado sensível)
create table audit_logs (
  id            bigserial primary key,
  therapist_id  uuid not null references therapists(id) on delete cascade,
  action        text not null,
  entity        text not null,
  entity_id     uuid,
  ip            inet,
  created_at    timestamptz not null default now()
);
create index audit_logs_therapist_idx on audit_logs(therapist_id, created_at desc);
