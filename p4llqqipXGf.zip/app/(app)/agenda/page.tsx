import type { Metadata } from 'next'
import { CalendarView } from '@/components/agenda/calendar-view'

export const metadata: Metadata = { title: 'Agenda' }

export default function AgendaPage() {
  return <CalendarView />
}
