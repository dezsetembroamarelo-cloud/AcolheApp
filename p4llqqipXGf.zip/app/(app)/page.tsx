import { PageHeader } from '@/components/shared/compliance-badges'
import { StatCards } from '@/components/dashboard/stat-cards'
import { TodaySessions } from '@/components/dashboard/today-sessions'
import { RevenueChart } from '@/components/dashboard/revenue-chart'
import { RecentRecords } from '@/components/dashboard/recent-records'
import { PendingPayments } from '@/components/dashboard/pending-payments'
import { TrialCard } from '@/components/dashboard/trial-card'
import { therapist } from '@/lib/data'

export default function DashboardPage() {
  const firstName = therapist.name.split(' ').slice(1, 2).join(' ')
  const today = new Date().toLocaleDateString('pt-BR', { weekday: 'long', day: 'numeric', month: 'long' })

  return (
    <div className="mx-auto max-w-7xl">
      <PageHeader title={`Bom dia, ${firstName}`} description={`Hoje é ${today}. Veja o resumo do seu consultório.`} />
      <StatCards />
      <div className="mt-6 grid gap-6 xl:grid-cols-3">
        <div className="flex flex-col gap-6 xl:col-span-2">
          <TodaySessions />
          <RevenueChart />
        </div>
        <div className="flex flex-col gap-6">
          <TrialCard />
          <PendingPayments />
          <RecentRecords />
        </div>
      </div>
    </div>
  )
}
