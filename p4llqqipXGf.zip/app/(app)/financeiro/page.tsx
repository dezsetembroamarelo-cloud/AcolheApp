import type { Metadata } from 'next'
import { PageHeader } from '@/components/shared/compliance-badges'
import { FinanceSummary } from '@/components/finance/finance-summary'
import { RevenueChart } from '@/components/dashboard/revenue-chart'
import { PatientBalances } from '@/components/finance/patient-balances'
import { PaymentsTable } from '@/components/finance/payments-table'

export const metadata: Metadata = { title: 'Financeiro' }

export default function FinanceiroPage() {
  return (
    <div className="mx-auto max-w-7xl">
      <PageHeader title="Financeiro" description="Receitas, pagamentos recebidos e pendências por paciente." />
      <FinanceSummary />
      <div className="mt-6 grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <RevenueChart />
        </div>
        <PatientBalances />
      </div>
      <div className="mt-6">
        <PaymentsTable />
      </div>
    </div>
  )
}
