import type { Metadata } from 'next'
import { PageHeader } from '@/components/shared/compliance-badges'
import { SubscriberCenter } from '@/components/billing/subscriber-center'

export const metadata: Metadata = { title: 'Assinatura' }

export default function AssinaturaPage() {
  return (
    <div className="mx-auto max-w-6xl">
      <PageHeader title="Central do assinante" description="Gerencie seu plano, forma de pagamento e faturas." />
      <SubscriberCenter />
    </div>
  )
}
