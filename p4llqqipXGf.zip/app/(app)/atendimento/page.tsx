import type { Metadata } from 'next'
import { LiveSession } from '@/components/session/live-session'
import { patients } from '@/lib/data'

export const metadata: Metadata = { title: 'Atendimento' }

export default async function AtendimentoPage({ searchParams }: { searchParams: Promise<{ paciente?: string }> }) {
  const { paciente } = await searchParams
  const initialPatientId = patients.some((p) => p.id === paciente) ? paciente! : patients[0].id
  return <LiveSession initialPatientId={initialPatientId} />
}
