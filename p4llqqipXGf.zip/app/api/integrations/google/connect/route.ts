import { NextResponse } from 'next/server'

const SCOPES = ['https://www.googleapis.com/auth/calendar.events', 'https://www.googleapis.com/auth/calendar.readonly']

/**
 * Inicia o OAuth do Google Calendar. O callback (/api/integrations/google/callback)
 * deve trocar o code por tokens, salvá-los criptografados em calendar_connections
 * e registrar um canal de push (events.watch) para sincronização bidirecional.
 */
export async function GET(req: Request) {
  const clientId = process.env.GOOGLE_CLIENT_ID
  if (!clientId) {
    return NextResponse.json(
      { error: 'Integração com Google Calendar ainda não configurada. Defina GOOGLE_CLIENT_ID e GOOGLE_CLIENT_SECRET.' },
      { status: 501 },
    )
  }
  const origin = new URL(req.url).origin
  const params = new URLSearchParams({
    client_id: clientId,
    redirect_uri: `${origin}/api/integrations/google/callback`,
    response_type: 'code',
    access_type: 'offline',
    prompt: 'consent',
    scope: SCOPES.join(' '),
  })
  return NextResponse.redirect(`https://accounts.google.com/o/oauth2/v2/auth?${params}`)
}
