import { timingSafeEqual } from 'node:crypto'
import { applyBillingEvent, type BillingEvent } from '@/lib/billing'

function safeEqual(a: string, b: string) {
  return a.length === b.length && timingSafeEqual(Buffer.from(a), Buffer.from(b))
}

export async function POST(req: Request) {
  const token = process.env.ASAAS_WEBHOOK_TOKEN
  if (!token) return Response.json({ error: 'Webhook não configurado' }, { status: 501 })

  const received = req.headers.get('asaas-access-token') ?? ''
  if (!safeEqual(received, token)) {
    return Response.json({ error: 'Token inválido' }, { status: 401 })
  }

  const event = await req.json()
  const payment = event.payment ?? {}

  const map: Record<string, BillingEvent['type'] | undefined> = {
    PAYMENT_RECEIVED: 'payment_succeeded',
    PAYMENT_CONFIRMED: 'payment_succeeded',
    PAYMENT_OVERDUE: 'payment_failed',
    SUBSCRIPTION_DELETED: 'subscription_canceled',
    SUBSCRIPTION_UPDATED: 'subscription_updated',
  }
  const type = map[event.event]

  if (type && payment.customer) {
    await applyBillingEvent({
      provider: 'asaas',
      eventId: event.id ?? `${event.event}:${payment.id}`,
      type,
      customerId: payment.customer,
      amountCents: payment.value ? Math.round(payment.value * 100) : null,
      invoiceUrl: payment.invoiceUrl ?? null,
      periodEnd: payment.dueDate ?? null,
    })
  }

  return Response.json({ received: true })
}
