import { generateText, Output } from 'ai'
import { z } from 'zod'
import { demoSubscription, evaluateAccess } from '@/lib/subscription'

export const maxDuration = 60

const recordSchema = z.object({
  objetivo: z.string().describe('Dados objetivos observados na sessão: demanda trazida, falas relevantes, comportamento, afeto.'),
  avaliacao: z.string().describe('Avaliação clínica: hipóteses, padrões, evolução em relação ao processo terapêutico.'),
  conduta: z.string().describe('Conduta adotada e plano: intervenções realizadas, tarefas, encaminhamentos, foco da próxima sessão.'),
  insights: z
    .array(
      z.object({
        type: z.enum(['alerta', 'padrao', 'sugestao', 'pergunta']),
        text: z.string().describe('Insight curto (máx. 160 caracteres).'),
      }),
    )
    .max(5)
    .describe('Insights do copiloto clínico para o profissional durante a sessão.'),
})

export type StructuredRecord = z.infer<typeof recordSchema>

const requestSchema = z.object({
  transcript: z.string().min(20).max(60_000),
  approach: z.string().max(60).optional(),
  final: z.boolean().optional(),
})

export async function POST(req: Request) {
  const parsed = requestSchema.safeParse(await req.json())
  if (!parsed.success) {
    return Response.json({ error: 'Transcrição muito curta para estruturar.' }, { status: 400 })
  }

  // TODO: substituir pela assinatura do usuário autenticado (tabela subscriptions).
  const access = evaluateAccess(demoSubscription)
  if (parsed.data.final && !access.canCreateRecord) {
    return Response.json({ error: access.reason }, { status: 402 })
  }

  const { output } = await generateText({
    model: 'openai/gpt-5.4-mini',
    output: Output.object({ schema: recordSchema }),
    instructions: `Você é um assistente de documentação clínica para psicólogos brasileiros. A partir da transcrição de uma sessão, redija o prontuário em português, em terceira pessoa, com linguagem técnica, ética e concisa (Resolução CFP 001/2009). Não invente fatos que não estejam na transcrição. Se uma seção não tiver informação suficiente, escreva "Sem registro suficiente nesta sessão.". Abordagem do profissional: ${parsed.data.approach ?? 'não informada'}.`,
    prompt: `Transcrição da sessão:\n\n${parsed.data.transcript}`,
  })

  return Response.json(output)
}
