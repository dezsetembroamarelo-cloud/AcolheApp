import { HeartHandshake } from 'lucide-react'

export function Logo() {
  return (
    <span className="flex items-center gap-2.5">
      <span className="flex size-9 items-center justify-center rounded-xl bg-primary text-primary-foreground shadow-sm">
        <HeartHandshake className="size-5" aria-hidden />
      </span>
      <span className="text-lg font-bold tracking-tight text-foreground">
        Acolhe<span className="text-primary">App</span>
      </span>
    </span>
  )
}
