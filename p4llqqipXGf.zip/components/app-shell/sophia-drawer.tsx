'use client'

import { useEffect, useRef, useState } from 'react'
import { useChat } from '@ai-sdk/react'
import { DefaultChatTransport } from 'ai'
import { ArrowUp, Loader2, ShieldCheck, Sparkles, Square, X } from 'lucide-react'
import { cn } from '@/lib/utils'
import { useSophia } from './app-shell'

const suggestions = [
  'Quais hipóteses diagnósticas considerar para ansiedade com sintomas somáticos?',
  'Sugira técnicas de TCC para reestruturação cognitiva em perfeccionismo.',
  'Como conduzir uma avaliação de risco de suicídio de forma estruturada?',
]

const transport = new DefaultChatTransport({ api: '/api/sophia' })

export function SophiaDrawer() {
  const { open, closeSophia, pendingPrompt, consumePrompt } = useSophia()
  const [input, setInput] = useState('')
  const { messages, sendMessage, status, stop, error } = useChat({ transport })
  const scrollRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLTextAreaElement>(null)
  const busy = status === 'submitted' || status === 'streaming'

  useEffect(() => {
    if (open && pendingPrompt) {
      const prompt = consumePrompt()
      if (prompt) sendMessage({ text: prompt })
    }
  }, [open, pendingPrompt, consumePrompt, sendMessage])

  useEffect(() => {
    if (open) inputRef.current?.focus()
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && closeSophia()
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [open, closeSophia])

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' })
  }, [messages])

  function submit(text: string) {
    const value = text.trim()
    if (!value || busy) return
    sendMessage({ text: value })
    setInput('')
  }

  return (
    <>
      <div
        aria-hidden
        onClick={closeSophia}
        className={cn(
          'fixed inset-0 z-40 bg-foreground/20 backdrop-blur-[2px] transition-opacity',
          open ? 'opacity-100' : 'pointer-events-none opacity-0',
        )}
      />
      <aside
        role="dialog"
        aria-modal="true"
        aria-label="Sophia, assistente de supervisão clínica"
        aria-hidden={!open}
        inert={!open}
        className={cn(
          'fixed inset-y-0 right-0 z-50 flex w-full max-w-md flex-col border-l border-border bg-card shadow-2xl transition-transform duration-300',
          open ? 'translate-x-0' : 'translate-x-full',
        )}
      >
        <header className="flex items-center gap-3 border-b border-border px-5 py-4">
          <span className="flex size-10 items-center justify-center rounded-xl bg-primary text-primary-foreground">
            <Sparkles className="size-5" aria-hidden />
          </span>
          <div className="flex-1">
            <h2 className="text-base font-semibold">Sophia</h2>
            <p className="text-xs text-muted-foreground">Supervisão clínica · hipóteses · condutas</p>
          </div>
          <button
            type="button"
            onClick={closeSophia}
            className="inline-flex size-9 items-center justify-center rounded-lg text-muted-foreground hover:bg-muted"
            aria-label="Fechar Sophia"
          >
            <X className="size-4" aria-hidden />
          </button>
        </header>

        <div ref={scrollRef} className="flex-1 overflow-y-auto px-5 py-5" aria-live="polite">
          {messages.length === 0 ? (
            <div className="flex flex-col gap-4">
              <div className="rounded-2xl bg-secondary p-4 text-sm leading-relaxed text-secondary-foreground">
                Olá! Sou a Sophia. Posso ajudar a discutir casos, levantar hipóteses e sugerir condutas baseadas em
                evidências. Lembre-se de anonimizar os dados do paciente.
              </div>
              <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Sugestões</p>
              <ul className="flex flex-col gap-2">
                {suggestions.map((s) => (
                  <li key={s}>
                    <button
                      type="button"
                      onClick={() => submit(s)}
                      className="w-full rounded-xl border border-border p-3 text-left text-sm text-foreground transition hover:border-primary hover:bg-secondary/50"
                    >
                      {s}
                    </button>
                  </li>
                ))}
              </ul>
            </div>
          ) : (
            <ul className="flex flex-col gap-4">
              {messages.map((m) => (
                <li key={m.id} className={cn('flex', m.role === 'user' ? 'justify-end' : 'justify-start')}>
                  <div
                    className={cn(
                      'max-w-[88%] whitespace-pre-wrap rounded-2xl px-4 py-3 text-sm leading-relaxed',
                      m.role === 'user' ? 'bg-primary text-primary-foreground' : 'bg-muted text-foreground',
                    )}
                  >
                    {m.parts.map((part, i) => (part.type === 'text' ? <span key={i}>{part.text}</span> : null))}
                  </div>
                </li>
              ))}
              {status === 'submitted' && (
                <li className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Loader2 className="size-4 animate-spin" aria-hidden />
                  Sophia está analisando...
                </li>
              )}
            </ul>
          )}
          {error && (
            <p role="alert" className="mt-4 rounded-xl bg-destructive/10 p-3 text-sm text-destructive">
              Não foi possível falar com a Sophia agora. Tente novamente.
            </p>
          )}
        </div>

        <form
          onSubmit={(e) => {
            e.preventDefault()
            submit(input)
          }}
          className="border-t border-border p-4"
        >
          <div className="flex items-end gap-2 rounded-2xl border border-border bg-background p-2 focus-within:border-primary focus-within:ring-3 focus-within:ring-primary/15">
            <label htmlFor="sophia-input" className="sr-only">
              Mensagem para Sophia
            </label>
            <textarea
              id="sophia-input"
              ref={inputRef}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.nativeEvent.isComposing || e.keyCode === 229) return
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault()
                  submit(input)
                }
              }}
              rows={2}
              placeholder="Descreva o caso ou faça uma pergunta clínica..."
              className="max-h-40 flex-1 resize-none bg-transparent px-2 py-1.5 text-sm outline-none placeholder:text-muted-foreground"
            />
            {busy ? (
              <button
                type="button"
                onClick={() => stop()}
                className="inline-flex size-9 items-center justify-center rounded-xl bg-foreground text-background"
                aria-label="Parar resposta"
              >
                <Square className="size-3.5" aria-hidden />
              </button>
            ) : (
              <button
                type="submit"
                disabled={!input.trim()}
                className="inline-flex size-9 items-center justify-center rounded-xl bg-primary text-primary-foreground disabled:opacity-40"
                aria-label="Enviar"
              >
                <ArrowUp className="size-4" aria-hidden />
              </button>
            )}
          </div>
          <p className="mt-2 flex items-center gap-1.5 text-[11px] text-muted-foreground">
            <ShieldCheck className="size-3.5 text-success" aria-hidden />
            Não substitui a supervisão humana. Não envie dados identificáveis.
          </p>
        </form>
      </aside>
    </>
  )
}
