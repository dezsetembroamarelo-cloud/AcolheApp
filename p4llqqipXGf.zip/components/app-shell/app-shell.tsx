'use client'

import { createContext, useCallback, useContext, useState } from 'react'
import { Sidebar, MobileNav } from './sidebar'
import { Topbar } from './topbar'
import { SophiaDrawer } from './sophia-drawer'

type SophiaContextValue = {
  open: boolean
  openSophia: (prompt?: string) => void
  closeSophia: () => void
  pendingPrompt: string | null
  consumePrompt: () => string | null
}

const SophiaContext = createContext<SophiaContextValue | null>(null)

export function useSophia() {
  const ctx = useContext(SophiaContext)
  if (!ctx) throw new Error('useSophia deve ser usado dentro de <AppShell>')
  return ctx
}

export function AppShell({ children }: { children: React.ReactNode }) {
  const [open, setOpen] = useState(false)
  const [pendingPrompt, setPendingPrompt] = useState<string | null>(null)

  const openSophia = useCallback((prompt?: string) => {
    if (prompt) setPendingPrompt(prompt)
    setOpen(true)
  }, [])
  const closeSophia = useCallback(() => setOpen(false), [])
  const consumePrompt = useCallback(() => {
    const value = pendingPrompt
    setPendingPrompt(null)
    return value
  }, [pendingPrompt])

  return (
    <SophiaContext.Provider value={{ open, openSophia, closeSophia, pendingPrompt, consumePrompt }}>
      <div className="flex min-h-dvh bg-background">
        <Sidebar />
        <div className="flex min-w-0 flex-1 flex-col">
          <Topbar />
          <MobileNav />
          <main className="flex-1 px-4 py-6 lg:px-8">{children}</main>
        </div>
      </div>
      <SophiaDrawer />
    </SophiaContext.Provider>
  )
}
