'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { CalendarDays, CreditCard, LayoutDashboard, Mic, Sparkles, Wallet } from 'lucide-react'
import { cn } from '@/lib/utils'
import { useSophia } from './app-shell'
import { Logo } from './logo'
import { ComplianceBadges } from '@/components/shared/compliance-badges'

export const navItems = [
  { href: '/', label: 'Painel', icon: LayoutDashboard },
  { href: '/atendimento', label: 'Atendimento', icon: Mic },
  { href: '/agenda', label: 'Agenda', icon: CalendarDays },
  { href: '/financeiro', label: 'Financeiro', icon: Wallet },
  { href: '/assinatura', label: 'Assinatura', icon: CreditCard },
]

function isActive(pathname: string, href: string) {
  return href === '/' ? pathname === '/' : pathname.startsWith(href)
}

export function Sidebar() {
  const pathname = usePathname()
  const { openSophia } = useSophia()

  return (
    <aside className="sticky top-0 hidden h-dvh w-64 shrink-0 flex-col border-r border-sidebar-border bg-sidebar px-4 py-5 lg:flex">
      <Link href="/" className="px-2">
        <Logo />
      </Link>

      <nav aria-label="Navegação principal" className="mt-8 flex flex-col gap-1">
        {navItems.map(({ href, label, icon: Icon }) => {
          const active = isActive(pathname, href)
          return (
            <Link
              key={href}
              href={href}
              aria-current={active ? 'page' : undefined}
              className={cn(
                'flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-colors',
                active
                  ? 'bg-sidebar-accent text-sidebar-accent-foreground'
                  : 'text-muted-foreground hover:bg-muted hover:text-foreground',
              )}
            >
              <Icon className="size-4" aria-hidden />
              {label}
            </Link>
          )
        })}
      </nav>

      <button
        type="button"
        onClick={() => openSophia()}
        className="mt-6 flex items-center gap-3 rounded-2xl bg-primary p-4 text-left text-primary-foreground shadow-md transition hover:brightness-110"
      >
        <span className="flex size-9 items-center justify-center rounded-xl bg-white/15">
          <Sparkles className="size-4" aria-hidden />
        </span>
        <span>
          <span className="block text-sm font-semibold">Sophia</span>
          <span className="block text-xs text-white/80">Supervisão clínica com IA</span>
        </span>
      </button>

      <div className="mt-auto">
        <ComplianceBadges vertical />
      </div>
    </aside>
  )
}

export function MobileNav() {
  const pathname = usePathname()
  return (
    <nav aria-label="Navegação principal" className="flex gap-1 overflow-x-auto border-b border-border bg-card px-4 py-2 lg:hidden">
      {navItems.map(({ href, label, icon: Icon }) => {
        const active = isActive(pathname, href)
        return (
          <Link
            key={href}
            href={href}
            aria-current={active ? 'page' : undefined}
            className={cn(
              'flex shrink-0 items-center gap-2 rounded-lg px-3 py-2 text-sm font-medium',
              active ? 'bg-secondary text-secondary-foreground' : 'text-muted-foreground',
            )}
          >
            <Icon className="size-4" aria-hidden />
            {label}
          </Link>
        )
      })}
    </nav>
  )
}
