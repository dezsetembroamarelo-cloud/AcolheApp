'use client'

import Link from 'next/link'
import { Bell, Mic, Search, Sparkles } from 'lucide-react'
import { therapist } from '@/lib/data'
import { demoSubscription, evaluateAccess } from '@/lib/subscription'
import { useSophia } from './app-shell'
import { Logo } from './logo'

export function Topbar() {
  const { openSophia } = useSophia()
  const access = evaluateAccess(demoSubscription)

  return (
    <header className="sticky top-0 z-30 flex h-16 items-center gap-3 border-b border-border bg-card/90 px-4 backdrop-blur lg:px-8">
      <Link href="/" className="lg:hidden">
        <Logo />
      </Link>

      <label className="relative hidden max-w-sm flex-1 md:block">
        <span className="sr-only">Buscar pacientes e prontuários</span>
        <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" aria-hidden />
        <input
          type="search"
          placeholder="Buscar pacientes, prontuários..."
          className="h-10 w-full rounded-xl border border-border bg-background pl-9 pr-3 text-sm outline-none transition focus:border-primary focus:ring-3 focus:ring-primary/15"
        />
      </label>

      <div className="ml-auto flex items-center gap-2">
        {demoSubscription.status === 'trialing' && access.daysLeft !== null && (
          <Link
            href="/assinatura"
            className="hidden rounded-full bg-secondary px-3 py-1.5 text-xs font-semibold text-secondary-foreground sm:inline-flex"
          >
            Teste grátis · {access.daysLeft} dias restantes
          </Link>
        )}
        <Link
          href="/atendimento"
          className="hidden h-10 items-center gap-2 rounded-xl bg-primary px-4 text-sm font-semibold text-primary-foreground shadow-sm transition hover:brightness-110 sm:inline-flex"
        >
          <Mic className="size-4" aria-hidden />
          Nova sessão
        </Link>
        <button
          type="button"
          onClick={() => openSophia()}
          className="inline-flex size-10 items-center justify-center rounded-xl border border-border text-primary transition hover:bg-secondary lg:hidden"
          aria-label="Abrir Sophia"
        >
          <Sparkles className="size-4" aria-hidden />
        </button>
        <button
          type="button"
          className="relative inline-flex size-10 items-center justify-center rounded-xl border border-border text-muted-foreground transition hover:bg-muted"
          aria-label="Notificações"
        >
          <Bell className="size-4" aria-hidden />
          <span className="absolute right-2.5 top-2.5 size-2 rounded-full bg-primary" />
        </button>
        <div className="hidden items-center gap-2.5 pl-2 md:flex">
          <span className="flex size-9 items-center justify-center rounded-full bg-secondary text-xs font-bold text-secondary-foreground">
            {therapist.initials}
          </span>
          <span className="leading-tight">
            <span className="block text-sm font-semibold">{therapist.name}</span>
            <span className="block text-xs text-muted-foreground">{therapist.crp}</span>
          </span>
        </div>
      </div>
    </header>
  )
}
