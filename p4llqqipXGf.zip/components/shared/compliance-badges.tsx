import { Lock, ShieldCheck } from 'lucide-react'
import { cn } from '@/lib/utils'

export function ComplianceBadges({ vertical = false, className }: { vertical?: boolean; className?: string }) {
  return (
    <div className={cn('flex gap-2', vertical ? 'flex-col' : 'flex-wrap', className)}>
      <span className="inline-flex items-center gap-2 rounded-xl border border-border bg-card px-3 py-2 text-xs font-medium text-foreground">
        <ShieldCheck className="size-4 text-success" aria-hidden />
        Conforme LGPD
      </span>
      <span className="inline-flex items-center gap-2 rounded-xl border border-border bg-card px-3 py-2 text-xs font-medium text-foreground">
        <Lock className="size-4 text-primary" aria-hidden />
        Sigilo profissional · CFP
      </span>
    </div>
  )
}

export function PageHeader({
  title,
  description,
  children,
}: {
  title: string
  description?: string
  children?: React.ReactNode
}) {
  return (
    <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-balance text-foreground">{title}</h1>
        {description && <p className="mt-1 text-sm text-muted-foreground text-pretty">{description}</p>}
      </div>
      {children && <div className="flex flex-wrap items-center gap-2">{children}</div>}
    </div>
  )
}

export function Card({ className, ...props }: React.ComponentProps<'section'>) {
  return <section className={cn('rounded-2xl border border-border bg-card shadow-sm', className)} {...props} />
}
