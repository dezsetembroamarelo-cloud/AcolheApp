import { cn } from '@/lib/utils'

const styles: Record<string, string> = {
  confirmado: 'bg-success/10 text-success',
  pago: 'bg-success/10 text-success',
  pendente: 'bg-warning/10 text-warning',
  atrasado: 'bg-destructive/10 text-destructive',
  cancelado: 'bg-muted text-muted-foreground',
}

export function StatusPill({ status, className }: { status: string; className?: string }) {
  return (
    <span
      className={cn(
        'inline-flex items-center rounded-full px-2.5 py-1 text-xs font-semibold capitalize',
        styles[status] ?? 'bg-muted text-muted-foreground',
        className,
      )}
    >
      {status}
    </span>
  )
}
