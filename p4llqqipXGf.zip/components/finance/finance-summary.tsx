import { AlertCircle, CheckCircle2, Clock, TrendingUp } from 'lucide-react'
import { brl, payments } from '@/lib/data'
import { Card } from '@/components/shared/compliance-badges'

export function FinanceSummary() {
  const sum = (s?: string) => payments.filter((p) => !s || p.status === s).reduce((t, p) => t + p.amount, 0)
  const received = sum('pago')
  const pending = sum('pendente')
  const overdue = sum('atrasado')
  const total = sum()

  const items = [
    { label: 'Faturado no mês', value: brl.format(total), icon: TrendingUp, tone: 'bg-secondary text-primary' },
    { label: 'Recebido', value: brl.format(received), icon: CheckCircle2, tone: 'bg-success/10 text-success' },
    { label: 'A receber', value: brl.format(pending), icon: Clock, tone: 'bg-warning/10 text-warning' },
    { label: 'Em atraso', value: brl.format(overdue), icon: AlertCircle, tone: 'bg-destructive/10 text-destructive' },
  ]

  return (
    <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
      {items.map(({ label, value, icon: Icon, tone }) => (
        <Card key={label} className="p-5">
          <span className={`flex size-10 items-center justify-center rounded-xl ${tone}`}>
            <Icon className="size-5" aria-hidden />
          </span>
          <p className="mt-4 text-sm text-muted-foreground">{label}</p>
          <p className="mt-1 text-xl font-bold tracking-tight tabular-nums sm:text-2xl">{value}</p>
        </Card>
      ))}
    </div>
  )
}
