import { brl, patients, payments } from '@/lib/data'
import { Card } from '@/components/shared/compliance-badges'

export function PatientBalances() {
  const rows = patients
    .map((p) => {
      const list = payments.filter((x) => x.patientId === p.id)
      const paid = list.filter((x) => x.status === 'pago').reduce((t, x) => t + x.amount, 0)
      const open = list.filter((x) => x.status !== 'pago').reduce((t, x) => t + x.amount, 0)
      return { ...p, paid, open }
    })
    .sort((a, b) => b.open - a.open)

  return (
    <Card className="p-5">
      <h2 className="font-semibold">Saldo por paciente</h2>
      <p className="text-sm text-muted-foreground">Pendências em aberto</p>
      <ul className="mt-4 flex flex-col gap-3">
        {rows.map((r) => (
          <li key={r.id} className="flex items-center gap-3">
            <span className="flex size-9 shrink-0 items-center justify-center rounded-full bg-secondary text-xs font-bold text-primary">
              {r.initials}
            </span>
            <div className="min-w-0 flex-1">
              <p className="truncate text-sm font-medium">{r.name}</p>
              <p className="text-xs text-muted-foreground">Pago: {brl.format(r.paid)}</p>
            </div>
            <span className={r.open > 0 ? 'text-sm font-semibold text-warning tabular-nums' : 'text-sm font-medium text-success'}>
              {r.open > 0 ? brl.format(r.open) : 'Em dia'}
            </span>
          </li>
        ))}
      </ul>
    </Card>
  )
}
