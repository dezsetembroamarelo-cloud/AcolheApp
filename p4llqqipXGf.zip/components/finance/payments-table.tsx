'use client'

import { useMemo, useState } from 'react'
import { Check, FileText, Search } from 'lucide-react'
import { cn } from '@/lib/utils'
import { brl, formatDate, getPatient, payments as initialPayments, therapist, type Payment } from '@/lib/data'
import { exportReceiptPdf } from '@/lib/pdf'
import { Card } from '@/components/shared/compliance-badges'
import { StatusPill } from '@/components/shared/status-pill'

const filters = [
  { id: 'todos', label: 'Todos' },
  { id: 'pago', label: 'Pagos' },
  { id: 'pendente', label: 'Pendentes' },
  { id: 'atrasado', label: 'Atrasados' },
] as const

export function PaymentsTable() {
  const [rows, setRows] = useState<Payment[]>(initialPayments)
  const [filter, setFilter] = useState<(typeof filters)[number]['id']>('todos')
  const [query, setQuery] = useState('')

  const visible = useMemo(
    () =>
      rows.filter(
        (p) =>
          (filter === 'todos' || p.status === filter) &&
          (getPatient(p.patientId)?.name.toLowerCase().includes(query.toLowerCase()) ?? false),
      ),
    [rows, filter, query],
  )

  function markPaid(id: string) {
    setRows((r) => r.map((p) => (p.id === id ? { ...p, status: 'pago' } : p)))
  }

  function receipt(p: Payment, index: number) {
    exportReceiptPdf({
      number: `${new Date().getFullYear()}-${String(index + 1).padStart(4, '0')}`,
      patient: getPatient(p.patientId)?.name ?? '',
      therapist: therapist.name,
      crp: therapist.crp,
      amount: p.amount,
      amountLabel: brl.format(p.amount),
      description: p.description,
      date: formatDate(p.date, { day: '2-digit', month: '2-digit', year: 'numeric' }),
      method: p.method,
    })
  }

  return (
    <Card>
      <div className="flex flex-col gap-3 border-b border-border p-4 md:flex-row md:items-center md:justify-between">
        <h2 className="font-semibold">Lançamentos</h2>
        <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
          <label className="relative">
            <span className="sr-only">Buscar paciente</span>
            <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" aria-hidden />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Buscar paciente"
              className="h-9 w-full rounded-xl border border-border bg-background pl-9 pr-3 text-sm outline-none focus:border-primary sm:w-56"
            />
          </label>
          <div className="flex rounded-xl bg-muted p-1">
            {filters.map((f) => (
              <button
                key={f.id}
                type="button"
                onClick={() => setFilter(f.id)}
                aria-pressed={filter === f.id}
                className={cn(
                  'h-7 rounded-lg px-3 text-xs font-medium transition',
                  filter === f.id ? 'bg-card text-foreground shadow-sm' : 'text-muted-foreground hover:text-foreground',
                )}
              >
                {f.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full min-w-[720px] text-sm">
          <thead>
            <tr className="text-left text-xs uppercase tracking-wide text-muted-foreground">
              <th className="px-4 py-3 font-medium">Paciente</th>
              <th className="px-4 py-3 font-medium">Descrição</th>
              <th className="px-4 py-3 font-medium">Data</th>
              <th className="px-4 py-3 font-medium">Método</th>
              <th className="px-4 py-3 text-right font-medium">Valor</th>
              <th className="px-4 py-3 font-medium">Status</th>
              <th className="px-4 py-3 text-right font-medium">
                <span className="sr-only">Ações</span>
              </th>
            </tr>
          </thead>
          <tbody>
            {visible.map((p) => {
              const patient = getPatient(p.patientId)
              const index = rows.findIndex((r) => r.id === p.id)
              return (
                <tr key={p.id} className="border-t border-border transition hover:bg-muted/40">
                  <td className="px-4 py-3 font-medium">{patient?.name}</td>
                  <td className="px-4 py-3 text-muted-foreground">{p.description}</td>
                  <td className="px-4 py-3 text-muted-foreground">{formatDate(p.date)}</td>
                  <td className="px-4 py-3 text-muted-foreground">{p.method}</td>
                  <td className="px-4 py-3 text-right font-semibold tabular-nums">{brl.format(p.amount)}</td>
                  <td className="px-4 py-3">
                    <StatusPill status={p.status} />
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex justify-end gap-1.5">
                      {p.status !== 'pago' ? (
                        <button
                          type="button"
                          onClick={() => markPaid(p.id)}
                          className="inline-flex h-8 items-center gap-1.5 rounded-lg border border-border px-2.5 text-xs font-semibold hover:bg-muted"
                        >
                          <Check className="size-3.5" aria-hidden />
                          Marcar pago
                        </button>
                      ) : (
                        <button
                          type="button"
                          onClick={() => receipt(p, index)}
                          className="inline-flex h-8 items-center gap-1.5 rounded-lg bg-secondary px-2.5 text-xs font-semibold text-secondary-foreground transition hover:bg-primary hover:text-primary-foreground"
                        >
                          <FileText className="size-3.5" aria-hidden />
                          Recibo PDF
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              )
            })}
            {visible.length === 0 && (
              <tr>
                <td colSpan={7} className="px-4 py-10 text-center text-sm text-muted-foreground">
                  Nenhum lançamento encontrado.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </Card>
  )
}
