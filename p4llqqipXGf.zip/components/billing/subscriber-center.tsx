'use client'

import { useState } from 'react'
import { Check, CreditCard, Download, QrCode, ShieldCheck, Sparkles } from 'lucide-react'
import { cn } from '@/lib/utils'
import { brl } from '@/lib/data'
import { demoSubscription, evaluateAccess, GRACE_PERIOD_DAYS, plans, TRIAL_RECORD_LIMIT } from '@/lib/subscription'
import { Card } from '@/components/shared/compliance-badges'
import { StatusPill } from '@/components/shared/status-pill'

const invoices = [
  { id: 'inv_0003', date: '01/10/2026', amount: 129, status: 'pago' },
  { id: 'inv_0002', date: '01/09/2026', amount: 129, status: 'pago' },
  { id: 'inv_0001', date: '01/08/2026', amount: 69, status: 'pago' },
]

export function SubscriberCenter() {
  const sub = demoSubscription
  const access = evaluateAccess(sub)
  const [method, setMethod] = useState<'cartao' | 'pix'>('cartao')
  const [confirmCancel, setConfirmCancel] = useState(false)
  const [notice, setNotice] = useState<string | null>(null)

  async function checkout(planId: string) {
    const res = await fetch('/api/billing/checkout', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ planId, method }),
    })
    const data = await res.json()
    if (data.url) window.location.href = data.url
    else setNotice(data.message ?? 'Não foi possível iniciar o checkout.')
  }

  return (
    <div className="flex flex-col gap-6">
      {notice && (
        <p role="status" className="rounded-2xl border border-primary/20 bg-secondary p-4 text-sm text-secondary-foreground">
          {notice}
        </p>
      )}

      <div className="grid gap-6 lg:grid-cols-3">
        <Card className="p-5 lg:col-span-2">
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <p className="text-sm text-muted-foreground">Plano atual</p>
              <h2 className="mt-1 text-xl font-bold">Teste gratuito</h2>
            </div>
            <span className="rounded-full bg-secondary px-3 py-1 text-xs font-bold text-primary">
              {access.daysLeft} dias restantes
            </span>
          </div>
          <div className="mt-5 grid gap-4 sm:grid-cols-2">
            <div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Prontuários usados</span>
                <span className="font-semibold">
                  {sub.recordsCreated}/{TRIAL_RECORD_LIMIT}
                </span>
              </div>
              <div className="mt-2 h-2 rounded-full bg-muted">
                <div className="h-2 rounded-full bg-primary" style={{ width: `${(sub.recordsCreated / TRIAL_RECORD_LIMIT) * 100}%` }} />
              </div>
            </div>
            <div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Dias de teste</span>
                <span className="font-semibold">{7 - (access.daysLeft ?? 0)}/7</span>
              </div>
              <div className="mt-2 h-2 rounded-full bg-muted">
                <div className="h-2 rounded-full bg-primary" style={{ width: `${((7 - (access.daysLeft ?? 0)) / 7) * 100}%` }} />
              </div>
            </div>
          </div>
          <div className="mt-5 rounded-xl bg-muted/60 p-4 text-sm text-muted-foreground">
            <p className="font-semibold text-foreground">Regras de acesso</p>
            <ul className="mt-2 list-disc space-y-1 pl-5">
              <li>O teste termina em 7 dias ou após {TRIAL_RECORD_LIMIT} prontuários, o que ocorrer primeiro.</li>
              <li>Após {GRACE_PERIOD_DAYS} dias de atraso, a criação de novos prontuários é bloqueada.</li>
              <li>Seu histórico clínico permanece sempre acessível para leitura.</li>
            </ul>
          </div>
        </Card>

        <Card className="p-5">
          <h2 className="font-semibold">Forma de pagamento</h2>
          <div role="radiogroup" aria-label="Forma de pagamento" className="mt-4 grid grid-cols-2 gap-2">
            {[
              { id: 'cartao' as const, label: 'Cartão recorrente', icon: CreditCard },
              { id: 'pix' as const, label: 'PIX automático', icon: QrCode },
            ].map(({ id, label, icon: Icon }) => (
              <button
                key={id}
                type="button"
                role="radio"
                aria-checked={method === id}
                onClick={() => setMethod(id)}
                className={cn(
                  'flex flex-col items-center gap-2 rounded-xl border p-3 text-xs font-semibold transition',
                  method === id ? 'border-primary bg-secondary text-primary' : 'border-border hover:bg-muted',
                )}
              >
                <Icon className="size-5" aria-hidden />
                {label}
              </button>
            ))}
          </div>
          <div className="mt-4 rounded-xl border border-dashed border-border p-3 text-sm text-muted-foreground">
            Nenhum cartão cadastrado.
          </div>
          <button
            type="button"
            onClick={() => setNotice('Para alterar o cartão você será direcionado ao portal seguro do provedor de pagamento.')}
            className="mt-3 inline-flex h-10 w-full items-center justify-center rounded-xl border border-border text-sm font-semibold hover:bg-muted"
          >
            Alterar cartão
          </button>
          <p className="mt-3 flex items-center gap-1.5 text-xs text-muted-foreground">
            <ShieldCheck className="size-3.5 text-success" aria-hidden />
            Pagamentos processados por Stripe ou Asaas. Não armazenamos dados de cartão.
          </p>
        </Card>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        {plans.map((plan) => (
          <Card key={plan.id} className={cn('relative p-6', plan.highlighted && 'border-primary ring-2 ring-primary/20')}>
            {plan.highlighted && (
              <span className="absolute -top-3 left-6 inline-flex items-center gap-1 rounded-full bg-primary px-3 py-1 text-xs font-bold text-primary-foreground">
                <Sparkles className="size-3" aria-hidden />
                Mais escolhido
              </span>
            )}
            <h3 className="text-lg font-bold">{plan.name}</h3>
            <p className="mt-1 text-sm text-muted-foreground">{plan.description}</p>
            <p className="mt-4">
              <span className="text-3xl font-bold tracking-tight">{brl.format(plan.price)}</span>
              <span className="text-sm text-muted-foreground">/mês</span>
            </p>
            <ul className="mt-5 flex flex-col gap-2.5">
              {plan.features.map((f) => (
                <li key={f} className="flex items-center gap-2 text-sm">
                  <Check className="size-4 shrink-0 text-primary" aria-hidden />
                  {f}
                </li>
              ))}
            </ul>
            <button
              type="button"
              onClick={() => checkout(plan.id)}
              className={cn(
                'mt-6 inline-flex h-11 w-full items-center justify-center rounded-xl text-sm font-semibold transition',
                plan.highlighted ? 'bg-primary text-primary-foreground shadow-sm hover:brightness-110' : 'border border-border hover:bg-muted',
              )}
            >
              Assinar {plan.name}
            </button>
          </Card>
        ))}
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <h2 className="border-b border-border px-5 py-4 font-semibold">Faturas</h2>
          <ul>
            {invoices.map((inv) => (
              <li key={inv.id} className="flex items-center gap-4 border-b border-border px-5 py-3 last:border-0">
                <span className="font-mono text-xs text-muted-foreground">{inv.id}</span>
                <span className="flex-1 text-sm">{inv.date}</span>
                <span className="text-sm font-semibold tabular-nums">{brl.format(inv.amount)}</span>
                <StatusPill status={inv.status} />
                <button
                  type="button"
                  onClick={() => setNotice(`A fatura ${inv.id} será baixada pelo portal do provedor de pagamento.`)}
                  className="inline-flex size-8 items-center justify-center rounded-lg text-muted-foreground hover:bg-muted"
                  aria-label={`Baixar fatura ${inv.id}`}
                >
                  <Download className="size-4" aria-hidden />
                </button>
              </li>
            ))}
          </ul>
        </Card>

        <Card className="p-5">
          <h2 className="font-semibold">Cancelar assinatura</h2>
          <p className="mt-1 text-sm text-muted-foreground">
            Você mantém acesso de leitura a todo o histórico. Pode reativar quando quiser.
          </p>
          {confirmCancel ? (
            <div className="mt-4 flex gap-2">
              <button
                type="button"
                onClick={() => {
                  setConfirmCancel(false)
                  setNotice('Cancelamento agendado para o fim do período atual.')
                }}
                className="inline-flex h-10 flex-1 items-center justify-center rounded-xl bg-destructive text-sm font-semibold text-white"
              >
                Confirmar
              </button>
              <button
                type="button"
                onClick={() => setConfirmCancel(false)}
                className="inline-flex h-10 flex-1 items-center justify-center rounded-xl border border-border text-sm font-semibold hover:bg-muted"
              >
                Voltar
              </button>
            </div>
          ) : (
            <button
              type="button"
              onClick={() => setConfirmCancel(true)}
              className="mt-4 inline-flex h-10 w-full items-center justify-center rounded-xl border border-destructive/30 text-sm font-semibold text-destructive hover:bg-destructive/5"
            >
              Cancelar plano
            </button>
          )}
        </Card>
      </div>
    </div>
  )
}
