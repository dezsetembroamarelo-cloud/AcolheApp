'use client'

import { useState } from 'react'
import { Check, ClipboardCopy, FileDown, Loader2, RefreshCw, Sparkles } from 'lucide-react'
import { cn } from '@/lib/utils'
import { Card } from '@/components/shared/compliance-badges'
import { exportRecordPdf } from '@/lib/pdf'

export type RecordState = { objetivo: string; avaliacao: string; conduta: string }

const sections: { key: keyof RecordState; label: string; pill: string; ring: string }[] = [
  { key: 'objetivo', label: 'Objetivo', pill: 'bg-secondary text-primary', ring: 'focus:border-primary' },
  { key: 'avaliacao', label: 'Avaliação', pill: 'bg-warning/10 text-warning', ring: 'focus:border-warning' },
  { key: 'conduta', label: 'Conduta', pill: 'bg-success/10 text-success', ring: 'focus:border-success' },
]

export function RecordPanel({
  record,
  onChange,
  structuring,
  error,
  finalized,
  onRegenerate,
  canRegenerate,
  meta,
}: {
  record: RecordState
  onChange: (r: RecordState) => void
  structuring: boolean
  error: string | null
  finalized: boolean
  onRegenerate: () => void
  canRegenerate: boolean
  meta: { patient: string; therapist: string; crp: string }
}) {
  const [copied, setCopied] = useState<string | null>(null)
  const hasContent = Object.values(record).some(Boolean)
  const date = new Date().toLocaleDateString('pt-BR')

  async function copy(text: string, id: string) {
    await navigator.clipboard.writeText(text)
    setCopied(id)
    window.setTimeout(() => setCopied(null), 1800)
  }

  const fullText = [
    `Prontuário — ${meta.patient} — ${date}`,
    ...sections.map((s) => `\n${s.label.toUpperCase()}\n${record[s.key]}`),
  ].join('\n')

  return (
    <Card className="flex h-full flex-col">
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-border px-5 py-4">
        <h2 className="flex items-center gap-2 font-semibold">
          <Sparkles className="size-4 text-primary" aria-hidden />
          Prontuário estruturado
        </h2>
        <div className="flex items-center gap-1.5">
          {structuring && (
            <span className="inline-flex items-center gap-1.5 text-xs text-muted-foreground">
              <Loader2 className="size-3.5 animate-spin" aria-hidden />
              Atualizando...
            </span>
          )}
          {finalized && !structuring && (
            <span className="rounded-full bg-success/10 px-2.5 py-1 text-xs font-semibold text-success">Finalizado</span>
          )}
          {canRegenerate && (
            <button
              type="button"
              onClick={onRegenerate}
              disabled={structuring}
              className="inline-flex size-8 items-center justify-center rounded-lg text-muted-foreground hover:bg-muted disabled:opacity-50"
              aria-label="Gerar novamente"
            >
              <RefreshCw className="size-4" aria-hidden />
            </button>
          )}
        </div>
      </div>

      <div className="flex flex-1 flex-col gap-5 px-5 py-5">
        {error && (
          <p role="alert" className="rounded-xl bg-destructive/10 p-3 text-sm text-destructive">
            {error}
          </p>
        )}
        {sections.map((s) => (
          <div key={s.key}>
            <div className="mb-2 flex items-center justify-between">
              <label htmlFor={`rec-${s.key}`} className={cn('rounded-full px-3 py-1 text-xs font-bold', s.pill)}>
                {s.label}
              </label>
              <button
                type="button"
                disabled={!record[s.key]}
                onClick={() => copy(record[s.key], s.key)}
                className="inline-flex items-center gap-1 rounded-md px-2 py-1 text-xs font-medium text-muted-foreground hover:bg-muted disabled:opacity-40"
              >
                {copied === s.key ? <Check className="size-3.5 text-success" aria-hidden /> : <ClipboardCopy className="size-3.5" aria-hidden />}
                {copied === s.key ? 'Copiado' : 'Copiar'}
              </button>
            </div>
            <textarea
              id={`rec-${s.key}`}
              value={record[s.key]}
              onChange={(e) => onChange({ ...record, [s.key]: e.target.value })}
              rows={5}
              placeholder={structuring ? 'Gerando com IA...' : 'Será preenchido automaticamente durante a sessão.'}
              className={cn(
                'w-full resize-y rounded-xl border border-border bg-background px-3.5 py-3 text-sm leading-relaxed outline-none transition placeholder:text-muted-foreground',
                s.ring,
                structuring && 'animate-pulse',
              )}
            />
          </div>
        ))}
      </div>

      <div className="flex flex-wrap gap-2 border-t border-border p-4">
        <button
          type="button"
          disabled={!hasContent}
          onClick={() => copy(fullText, 'all')}
          className="inline-flex h-10 flex-1 items-center justify-center gap-2 rounded-xl border border-border text-sm font-semibold transition hover:bg-muted disabled:opacity-50"
        >
          {copied === 'all' ? <Check className="size-4 text-success" aria-hidden /> : <ClipboardCopy className="size-4" aria-hidden />}
          {copied === 'all' ? 'Copiado!' : 'Copiar tudo'}
        </button>
        <button
          type="button"
          disabled={!hasContent}
          onClick={() =>
            exportRecordPdf({
              ...meta,
              date,
              sections: sections.map((s) => ({ label: s.label, content: record[s.key] })),
            })
          }
          className="inline-flex h-10 flex-1 items-center justify-center gap-2 rounded-xl bg-primary text-sm font-semibold text-primary-foreground shadow-sm transition hover:brightness-110 disabled:opacity-50"
        >
          <FileDown className="size-4" aria-hidden />
          Exportar PDF
        </button>
      </div>
    </Card>
  )
}
