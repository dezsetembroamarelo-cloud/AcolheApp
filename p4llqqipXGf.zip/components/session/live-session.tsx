'use client'

import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { patients, therapist } from '@/lib/data'
import { demoSubscription, evaluateAccess } from '@/lib/subscription'
import { ComplianceBadges } from '@/components/shared/compliance-badges'
import { useSessionRecorder } from './use-session-recorder'
import { RecorderCard } from './recorder-card'
import { TranscriptPanel } from './transcript-panel'
import { RecordPanel, type RecordState } from './record-panel'
import { CopilotPanel, type Insight } from './copilot-panel'
import { AccessBanner } from './access-banner'

const emptyRecord: RecordState = { objetivo: '', avaliacao: '', conduta: '' }
const LIVE_UPDATE_EVERY = 3

export function LiveSession({ initialPatientId }: { initialPatientId: string }) {
  const [patientId, setPatientId] = useState(initialPatientId)
  const patient = patients.find((p) => p.id === patientId)!
  const recorder = useSessionRecorder()
  const access = evaluateAccess(demoSubscription)

  const [record, setRecord] = useState<RecordState>(emptyRecord)
  const [insights, setInsights] = useState<Insight[]>([])
  const [structuring, setStructuring] = useState(false)
  const [structureError, setStructureError] = useState<string | null>(null)
  const [finalized, setFinalized] = useState(false)
  const lastStructuredCount = useRef(0)
  const inFlight = useRef(false)

  const transcriptText = useMemo(
    () => recorder.segments.map((s) => `${s.speaker}: ${s.text}`).join('\n'),
    [recorder.segments],
  )

  const structure = useCallback(
    async (final: boolean) => {
      if (inFlight.current || transcriptText.length < 20) return
      inFlight.current = true
      setStructuring(true)
      setStructureError(null)
      lastStructuredCount.current = recorder.segments.length
      try {
        const res = await fetch('/api/prontuario', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ transcript: transcriptText, approach: patient.approach, final }),
        })
        const data = await res.json()
        if (!res.ok) throw new Error(data.error ?? 'Falha ao estruturar prontuário.')
        setRecord({ objetivo: data.objetivo, avaliacao: data.avaliacao, conduta: data.conduta })
        setInsights(data.insights ?? [])
        if (final) setFinalized(true)
      } catch (err) {
        setStructureError(err instanceof Error ? err.message : 'Falha ao estruturar prontuário.')
      } finally {
        inFlight.current = false
        setStructuring(false)
      }
    },
    [transcriptText, patient.approach, recorder.segments.length],
  )

  useEffect(() => {
    if (recorder.mode === 'idle' || recorder.paused) return
    if (recorder.segments.length - lastStructuredCount.current >= LIVE_UPDATE_EVERY) structure(false)
  }, [recorder.segments.length, recorder.mode, recorder.paused, structure])

  function handleFinish() {
    recorder.stop()
    structure(true)
  }

  function handleReset() {
    recorder.reset()
    setRecord(emptyRecord)
    setInsights([])
    setFinalized(false)
    setStructureError(null)
    lastStructuredCount.current = 0
  }

  return (
    <div className="mx-auto max-w-[1600px]">
      <div className="mb-6 flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Atendimento em tempo real</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Grave, transcreva e gere o prontuário estruturado automaticamente.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-3">
          <label className="flex items-center gap-2 text-sm">
            <span className="text-muted-foreground">Paciente</span>
            <select
              value={patientId}
              onChange={(e) => setPatientId(e.target.value)}
              disabled={recorder.mode !== 'idle'}
              className="h-10 rounded-xl border border-border bg-card px-3 text-sm font-medium outline-none focus:border-primary disabled:opacity-60"
            >
              {patients.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name} · {p.approach}
                </option>
              ))}
            </select>
          </label>
          <ComplianceBadges />
        </div>
      </div>

      <AccessBanner access={access} />

      <div className="grid gap-6 xl:grid-cols-12">
        <div className="flex flex-col gap-6 xl:col-span-5">
          <RecorderCard
            recorder={recorder}
            canCreate={access.canCreateRecord}
            onFinish={handleFinish}
            onReset={handleReset}
            hasContent={recorder.segments.length > 0}
          />
          <TranscriptPanel segments={recorder.segments} interim={recorder.interim} live={recorder.mode !== 'idle' && !recorder.paused} />
        </div>

        <div className="xl:col-span-4">
          <RecordPanel
            record={record}
            onChange={setRecord}
            structuring={structuring}
            error={structureError}
            finalized={finalized}
            onRegenerate={() => structure(true)}
            canRegenerate={recorder.segments.length > 0 && access.canCreateRecord}
            meta={{ patient: patient.name, therapist: therapist.name, crp: therapist.crp }}
          />
        </div>

        <div className="xl:col-span-3">
          <CopilotPanel insights={insights} live={recorder.mode !== 'idle'} structuring={structuring} patientApproach={patient.approach} record={record} />
        </div>
      </div>
    </div>
  )
}
