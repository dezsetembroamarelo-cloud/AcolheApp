'use client'

import { useEffect, useRef } from 'react'
import { AudioLines } from 'lucide-react'
import { cn } from '@/lib/utils'
import { Card } from '@/components/shared/compliance-badges'
import type { Segment } from './use-session-recorder'

export function TranscriptPanel({ segments, interim, live }: { segments: Segment[]; interim: string; live: boolean }) {
  const scrollRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' })
  }, [segments.length, interim])

  return (
    <Card className="flex min-h-[420px] flex-col">
      <div className="flex items-center justify-between border-b border-border px-5 py-4">
        <h2 className="flex items-center gap-2 font-semibold">
          <AudioLines className="size-4 text-primary" aria-hidden />
          Transcrição
        </h2>
        {live && <span className="text-xs font-medium text-primary">Ao vivo</span>}
      </div>
      <div ref={scrollRef} className="max-h-[520px] flex-1 overflow-y-auto px-5 py-4" aria-live="polite">
        {segments.length === 0 && !interim ? (
          <div className="flex h-full flex-col items-center justify-center py-12 text-center">
            <span className="flex size-12 items-center justify-center rounded-2xl bg-secondary text-primary">
              <AudioLines className="size-6" aria-hidden />
            </span>
            <p className="mt-3 text-sm font-medium">Nenhuma fala transcrita ainda</p>
            <p className="mt-1 max-w-xs text-sm text-muted-foreground">
              Inicie a gravação ou simule uma sessão para ver a transcrição em tempo real.
            </p>
          </div>
        ) : (
          <ol className="flex flex-col gap-3">
            {segments.map((s) => (
              <li key={s.id} className="flex gap-3 animate-in fade-in slide-in-from-bottom-1">
                <span
                  className={cn(
                    'mt-0.5 h-fit shrink-0 rounded-md px-2 py-0.5 text-[11px] font-semibold',
                    s.speaker === 'Paciente' ? 'bg-secondary text-secondary-foreground' : 'bg-muted text-muted-foreground',
                  )}
                >
                  {s.speaker}
                </span>
                <p className="text-sm leading-relaxed">{s.text}</p>
              </li>
            ))}
            {interim && (
              <li className="flex gap-3">
                <span className="mt-0.5 h-fit shrink-0 rounded-md bg-muted px-2 py-0.5 text-[11px] font-semibold text-muted-foreground">
                  ...
                </span>
                <p className="text-sm italic text-muted-foreground">{interim}</p>
              </li>
            )}
          </ol>
        )}
      </div>
    </Card>
  )
}
