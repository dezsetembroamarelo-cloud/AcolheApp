import Link from 'next/link'
import { AlertTriangle, Info } from 'lucide-react'
import type { Access } from '@/lib/subscription'

export function AccessBanner({ access }: { access: Access }) {
  if (!access.reason) return null
  const blocked = !access.canCreateRecord
  return (
    <div
      role="status"
      className={
        blocked
          ? 'mb-6 flex items-center gap-3 rounded-2xl border border-destructive/20 bg-destructive/5 p-4 text-sm text-destructive'
          : 'mb-6 flex items-center gap-3 rounded-2xl border border-warning/20 bg-warning/5 p-4 text-sm text-warning'
      }
    >
      {blocked ? <AlertTriangle className="size-5 shrink-0" aria-hidden /> : <Info className="size-5 shrink-0" aria-hidden />}
      <p className="flex-1">{access.reason}</p>
      <Link href="/assinatura" className="shrink-0 font-semibold underline underline-offset-4">
        Central do assinante
      </Link>
    </div>
  )
}
