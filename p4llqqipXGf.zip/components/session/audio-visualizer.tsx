'use client'

import { useEffect, useRef } from 'react'

const BARS = 48

export function AudioVisualizer({
  analyser,
  active,
  simulated,
}: {
  analyser: AnalyserNode | null
  active: boolean
  simulated: boolean
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    if (!ctx) return

    const dpr = window.devicePixelRatio || 1
    const resize = () => {
      canvas.width = canvas.clientWidth * dpr
      canvas.height = canvas.clientHeight * dpr
    }
    resize()
    const observer = new ResizeObserver(resize)
    observer.observe(canvas)

    const data = new Uint8Array(analyser?.frequencyBinCount ?? BARS)
    let frame = 0
    let raf = 0

    const draw = () => {
      frame += 1
      const { width, height } = canvas
      ctx.clearRect(0, 0, width, height)
      if (analyser && active) analyser.getByteFrequencyData(data)

      const gap = 3 * dpr
      const barWidth = (width - gap * (BARS - 1)) / BARS
      for (let i = 0; i < BARS; i++) {
        let level: number
        if (!active) level = 0.06
        else if (simulated || !analyser) {
          level = 0.15 + 0.55 * Math.abs(Math.sin(frame / 9 + i * 0.45) * Math.cos(frame / 23 + i * 0.2))
        } else {
          const bin = data[Math.floor((i / BARS) * data.length * 0.75)] ?? 0
          level = Math.max(0.06, bin / 255)
        }
        const h = Math.max(4 * dpr, level * height)
        const x = i * (barWidth + gap)
        const y = (height - h) / 2
        ctx.fillStyle = active ? `rgba(99, 102, 241, ${0.45 + level * 0.55})` : 'rgba(165, 180, 252, 0.5)'
        ctx.beginPath()
        ctx.roundRect(x, y, barWidth, h, barWidth / 2)
        ctx.fill()
      }
      raf = requestAnimationFrame(draw)
    }
    draw()

    return () => {
      cancelAnimationFrame(raf)
      observer.disconnect()
    }
  }, [analyser, active, simulated])

  return <canvas ref={canvasRef} className="h-20 w-full" role="img" aria-label={active ? 'Onda sonora da gravação em andamento' : 'Gravação parada'} />
}
