'use client'

import { AlertTriangle, Brain, HelpCircle, Lightbulb, Sparkles, Waypoints } from 'lucide-react'
import { cn } from '@/lib/utils'
import { Card } from '@/components/shared/compliance-badges'
import { useSophia } from '@/components/app-shell/app-shell'
import type { RecordState } from './record-panel'

export type Insight = { type: 'alerta' | 'padrao' | 'sugestao' | 'pergunta'; text: string }

const insightStyle = {
  alerta: { icon: AlertTriangle, label: 'Alerta', className: 'bg-destructive/10 text-destructive' },
  padrao: { icon: Waypoints, label: 'Padrão', className: 'bg-secondary text-primary' },
  sugestao: { icon: Lightbulb, label: 'Sugestão', className: 'bg-success/10 text-success' },
  pergunta: { icon: HelpCircle, label: 'Pergunta', className: 'bg-warning/10 text-warning' },
}

export function CopilotPanel({
  insights,
  live,
  structuring,
  patientApproach,
  record,
}: {
  insights: Insight[]
  live: boolean
  structuring: boolean
  patientApproach: string
  record: RecordState
}) {
  const { openSophia } = useSophia()

  const discussPrompt = `Quero discutir um caso (dados anonimizados, abordagem ${patientApproach}).\n\nAvaliação da sessão: ${record.avaliacao || '—'}\n\nConduta: ${record.conduta || '—'}\n\nQuais hipóteses e próximos passos você sugere?`

  return (
    <Card className="flex h-full flex-col">
      <div className="flex items-center justify-between border-b border-border px-5 py-4">
        <h2 className="flex items-center gap-2 font-semibold">
          <Brain className="size-4 text-primary" aria-hidden />
          Copiloto clínico
        </h2>
        {live && (
          <span className="flex items-center gap-1.5 text-xs font-medium text-primary">
            <span className="size-1.5 animate-pulse rounded-full bg-primary" aria-hidden />
            Ouvindo
          </span>
        )}
      </div>

      <div className="flex-1 px-5 py-4" aria-live="polite">
        {insights.length === 0 ? (
          <p className="rounded-xl bg-muted/60 p-4 text-sm text-muted-foreground">
            {structuring
              ? 'Analisando a sessão...'
              : 'Insights, padrões e perguntas sugeridas aparecerão aqui conforme a sessão avança.'}
          </p>
        ) : (
          <ul className="flex flex-col gap-3">
            {insights.map((insight, i) => {
              const style = insightStyle[insight.type]
              const Icon = style.icon
              return (
                <li key={`${insight.type}-${i}`} className="rounded-xl border border-border p-3">
                  <span className={cn('inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[11px] font-semibold', style.className)}>
                    <Icon className="size-3" aria-hidden />
                    {style.label}
                  </span>
                  <p className="mt-2 text-sm leading-relaxed">{insight.text}</p>
                </li>
              )
            })}
          </ul>
        )}
      </div>

      <div className="border-t border-border p-4">
        <button
          type="button"
          onClick={() => openSophia(record.avaliacao ? discussPrompt : undefined)}
          className="inline-flex h-10 w-full items-center justify-center gap-2 rounded-xl bg-secondary text-sm font-semibold text-secondary-foreground transition hover:bg-primary hover:text-primary-foreground"
        >
          <Sparkles className="size-4" aria-hidden />
          Discutir caso com Sophia
        </button>
      </div>
    </Card>
  )
}
