'use client'

import { Mic, Pause, Play, PlayCircle, RotateCcw, Square } from 'lucide-react'
import { cn } from '@/lib/utils'
import { Card } from '@/components/shared/compliance-badges'
import { AudioVisualizer } from './audio-visualizer'
import type { useSessionRecorder } from './use-session-recorder'

function formatTime(total: number) {
  const m = Math.floor(total / 60).toString().padStart(2, '0')
  const s = (total % 60).toString().padStart(2, '0')
  return `${m}:${s}`
}

export function RecorderCard({
  recorder,
  canCreate,
  onFinish,
  onReset,
  hasContent,
}: {
  recorder: ReturnType<typeof useSessionRecorder>
  canCreate: boolean
  onFinish: () => void
  onReset: () => void
  hasContent: boolean
}) {
  const { mode, paused, elapsed, error, analyser } = recorder
  const recording = mode !== 'idle'
  const active = recording && !paused

  return (
    <Card className="p-5">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span
            className={cn('size-2.5 rounded-full', active ? 'animate-pulse bg-destructive' : 'bg-muted-foreground/40')}
            aria-hidden
          />
          <span className="text-sm font-semibold">
            {active ? 'Gravando' : paused ? 'Pausado' : 'Pronto para gravar'}
            {mode === 'demo' && <span className="ml-2 rounded-full bg-secondary px-2 py-0.5 text-[11px] text-secondary-foreground">Demonstração</span>}
          </span>
        </div>
        <span className="font-mono text-sm tabular-nums text-muted-foreground" aria-label="Duração da sessão">
          {formatTime(elapsed)}
        </span>
      </div>

      <div className="mt-4 rounded-xl bg-secondary/60 px-4 py-3">
        <AudioVisualizer analyser={analyser} active={active} simulated={mode === 'demo'} />
      </div>

      {error && (
        <p role="alert" className="mt-3 rounded-xl bg-destructive/10 p-3 text-xs text-destructive">
          {error}
        </p>
      )}

      <div className="mt-4 flex flex-wrap items-center gap-2">
        {!recording ? (
          <>
            <button
              type="button"
              onClick={recorder.startMic}
              disabled={!canCreate}
              className="inline-flex h-11 flex-1 items-center justify-center gap-2 rounded-xl bg-primary px-5 text-sm font-semibold text-primary-foreground shadow-sm transition hover:brightness-110 disabled:cursor-not-allowed disabled:opacity-50"
            >
              <Mic className="size-4" aria-hidden />
              Iniciar gravação
            </button>
            <button
              type="button"
              onClick={recorder.startDemo}
              disabled={!canCreate}
              className="inline-flex h-11 items-center justify-center gap-2 rounded-xl border border-border px-4 text-sm font-semibold transition hover:bg-muted disabled:opacity-50"
            >
              <PlayCircle className="size-4" aria-hidden />
              Simular sessão
            </button>
            {hasContent && (
              <button
                type="button"
                onClick={onReset}
                className="inline-flex size-11 items-center justify-center rounded-xl border border-border text-muted-foreground transition hover:bg-muted"
                aria-label="Nova sessão"
              >
                <RotateCcw className="size-4" aria-hidden />
              </button>
            )}
          </>
        ) : (
          <>
            <button
              type="button"
              onClick={recorder.togglePause}
              className="inline-flex h-11 items-center justify-center gap-2 rounded-xl border border-border px-4 text-sm font-semibold transition hover:bg-muted"
            >
              {paused ? <Play className="size-4" aria-hidden /> : <Pause className="size-4" aria-hidden />}
              {paused ? 'Retomar' : 'Pausar'}
            </button>
            <button
              type="button"
              onClick={onFinish}
              className="inline-flex h-11 flex-1 items-center justify-center gap-2 rounded-xl bg-foreground px-5 text-sm font-semibold text-background transition hover:opacity-90"
            >
              <Square className="size-4" aria-hidden />
              Finalizar e gerar prontuário
            </button>
          </>
        )}
      </div>
      <p className="mt-3 text-xs text-muted-foreground">
        O áudio é processado no navegador e não é armazenado. Obtenha o consentimento do paciente antes de gravar.
      </p>
    </Card>
  )
}
