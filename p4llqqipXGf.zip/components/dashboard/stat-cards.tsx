import { CalendarCheck, FileText, TrendingUp, Wallet } from 'lucide-react'
import { appointments, brl, monthlyRevenue, payments } from '@/lib/data'
import { Card } from '@/components/shared/compliance-badges'

export function StatCards() {
  const todayIso = new Date().toISOString().slice(0, 10)
  const todayCount = appointments.filter((a) => a.date === todayIso && a.status !== 'cancelado').length
  const pending = payments.filter((p) => p.status !== 'pago').reduce((sum, p) => sum + p.amount, 0)
  const current = monthlyRevenue.at(-1)!.value
  const previous = monthlyRevenue.at(-2)!.value
  const growth = Math.round(((current - previous) / previous) * 100)

  const stats = [
    { label: 'Sessões hoje', value: String(todayCount), hint: 'agendadas', icon: CalendarCheck },
    { label: 'Receita do mês', value: brl.format(current), hint: `+${growth}% vs. mês anterior`, icon: TrendingUp },
    { label: 'A receber', value: brl.format(pending), hint: 'pendentes e em atraso', icon: Wallet },
    { label: 'Prontuários no mês', value: '38', hint: '12h economizadas com IA', icon: FileText },
  ]

  return (
    <ul className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
      {stats.map(({ label, value, hint, icon: Icon }) => (
        <li key={label}>
          <Card className="flex items-start justify-between p-5">
            <div>
              <p className="text-sm text-muted-foreground">{label}</p>
              <p className="mt-2 text-2xl font-bold tracking-tight">{value}</p>
              <p className="mt-1 text-xs text-muted-foreground">{hint}</p>
            </div>
            <span className="flex size-10 items-center justify-center rounded-xl bg-secondary text-primary">
              <Icon className="size-5" aria-hidden />
            </span>
          </Card>
        </li>
      ))}
    </ul>
  )
}
