import Link from 'next/link'
import { brl, formatDate, getPatient, payments } from '@/lib/data'
import { Card } from '@/components/shared/compliance-badges'
import { StatusPill } from '@/components/shared/status-pill'

export function PendingPayments() {
  const pending = payments.filter((p) => p.status !== 'pago')
  return (
    <Card>
      <div className="flex items-center justify-between border-b border-border px-5 py-4">
        <h2 className="font-semibold">Pendências</h2>
        <Link href="/financeiro" className="text-sm font-medium text-primary hover:underline">
          Financeiro
        </Link>
      </div>
      <ul className="divide-y divide-border">
        {pending.map((p) => (
          <li key={p.id} className="flex items-center justify-between gap-3 px-5 py-3.5">
            <div className="min-w-0">
              <p className="truncate text-sm font-medium">{getPatient(p.patientId)?.name}</p>
              <p className="text-xs text-muted-foreground">{formatDate(p.date)} · {p.description}</p>
            </div>
            <div className="flex flex-col items-end gap-1">
              <span className="text-sm font-semibold">{brl.format(p.amount)}</span>
              <StatusPill status={p.status} />
            </div>
          </li>
        ))}
      </ul>
    </Card>
  )
}
