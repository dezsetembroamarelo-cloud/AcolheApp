import Link from 'next/link'
import { Sparkles } from 'lucide-react'
import { TRIAL_DAYS, TRIAL_RECORD_LIMIT, demoSubscription, evaluateAccess } from '@/lib/subscription'

export function TrialCard() {
  if (demoSubscription.status !== 'trialing') return null
  const access = evaluateAccess(demoSubscription)
  const used = demoSubscription.recordsCreated
  const daysUsed = TRIAL_DAYS - (access.daysLeft ?? 0)

  return (
    <section className="rounded-2xl bg-primary p-5 text-primary-foreground shadow-md">
      <div className="flex items-center gap-2 text-sm font-semibold">
        <Sparkles className="size-4" aria-hidden />
        Teste gratuito
      </div>
      <p className="mt-2 text-sm text-white/85">
        {access.daysLeft} dias restantes · {used} de {TRIAL_RECORD_LIMIT} prontuários usados. O que acontecer primeiro
        encerra o teste.
      </p>
      <div className="mt-4 flex flex-col gap-3 text-xs">
        <Meter label="Dias" value={daysUsed} max={TRIAL_DAYS} />
        <Meter label="Prontuários" value={used} max={TRIAL_RECORD_LIMIT} />
      </div>
      <Link
        href="/assinatura"
        className="mt-5 inline-flex h-10 w-full items-center justify-center rounded-xl bg-white text-sm font-semibold text-primary transition hover:bg-secondary"
      >
        Assinar agora
      </Link>
    </section>
  )
}

function Meter({ label, value, max }: { label: string; value: number; max: number }) {
  return (
    <div>
      <div className="mb-1 flex justify-between text-white/80">
        <span>{label}</span>
        <span>
          {value}/{max}
        </span>
      </div>
      <div className="h-1.5 rounded-full bg-white/20" role="progressbar" aria-label={label} aria-valuenow={value} aria-valuemin={0} aria-valuemax={max}>
        <div className="h-full rounded-full bg-white" style={{ width: `${Math.min(100, (value / max) * 100)}%` }} />
      </div>
    </div>
  )
}
