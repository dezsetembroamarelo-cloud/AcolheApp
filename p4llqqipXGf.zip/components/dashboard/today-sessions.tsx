import Link from 'next/link'
import { ArrowRight, Mic, Video, MapPin } from 'lucide-react'
import { appointments, getPatient } from '@/lib/data'
import { Card } from '@/components/shared/compliance-badges'
import { StatusPill } from '@/components/shared/status-pill'

export function TodaySessions() {
  const todayIso = new Date().toISOString().slice(0, 10)
  const list = appointments.filter((a) => a.date === todayIso).sort((a, b) => a.start.localeCompare(b.start))

  return (
    <Card>
      <div className="flex items-center justify-between border-b border-border px-5 py-4">
        <h2 className="font-semibold">Sessões de hoje</h2>
        <Link href="/agenda" className="inline-flex items-center gap-1 text-sm font-medium text-primary hover:underline">
          Ver agenda <ArrowRight className="size-4" aria-hidden />
        </Link>
      </div>
      <ul className="divide-y divide-border">
        {list.map((a) => {
          const patient = getPatient(a.patientId)!
          return (
            <li key={a.id} className="flex flex-wrap items-center gap-4 px-5 py-4">
              <div className="w-16 text-sm">
                <p className="font-semibold">{a.start}</p>
                <p className="text-muted-foreground">{a.end}</p>
              </div>
              <span className="flex size-10 items-center justify-center rounded-full bg-secondary text-xs font-bold text-secondary-foreground">
                {patient.initials}
              </span>
              <div className="min-w-0 flex-1">
                <p className="truncate font-medium">{patient.name}</p>
                <p className="flex items-center gap-1.5 text-xs text-muted-foreground">
                  {a.modality === 'online' ? <Video className="size-3.5" aria-hidden /> : <MapPin className="size-3.5" aria-hidden />}
                  {a.modality === 'online' ? 'Online' : 'Presencial'} · {patient.approach}
                </p>
              </div>
              <StatusPill status={a.status} />
              <Link
                href={`/atendimento?paciente=${patient.id}`}
                className="inline-flex h-9 items-center gap-2 rounded-xl bg-secondary px-3 text-sm font-semibold text-secondary-foreground transition hover:bg-primary hover:text-primary-foreground"
              >
                <Mic className="size-4" aria-hidden />
                Iniciar
              </Link>
            </li>
          )
        })}
      </ul>
    </Card>
  )
}
