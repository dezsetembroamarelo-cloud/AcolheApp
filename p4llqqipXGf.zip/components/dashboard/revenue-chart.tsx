import { brl, monthlyRevenue } from '@/lib/data'
import { Card } from '@/components/shared/compliance-badges'

export function RevenueChart({ title = 'Receita dos últimos 6 meses' }: { title?: string }) {
  const max = Math.max(...monthlyRevenue.map((m) => m.value))
  const total = monthlyRevenue.reduce((s, m) => s + m.value, 0)

  return (
    <Card className="p-5">
      <div className="flex items-start justify-between">
        <div>
          <h2 className="font-semibold">{title}</h2>
          <p className="text-sm text-muted-foreground">Total no período: {brl.format(total)}</p>
        </div>
      </div>
      <figure className="mt-6">
        <ul className="flex h-48 items-end gap-3 sm:gap-6" aria-label="Gráfico de barras de receita mensal">
          {monthlyRevenue.map((m, i) => {
            const isLast = i === monthlyRevenue.length - 1
            return (
              <li key={m.month} className="flex h-full flex-1 flex-col items-center justify-end gap-2">
                <span className="text-[11px] font-medium text-muted-foreground">
                  {(m.value / 1000).toFixed(1).replace('.', ',')}k
                </span>
                <div
                  className={isLast ? 'w-full rounded-xl bg-primary' : 'w-full rounded-xl bg-secondary'}
                  style={{ height: `${(m.value / max) * 100}%` }}
                  aria-label={`${m.month}: ${brl.format(m.value)}`}
                  role="img"
                />
                <span className="text-xs font-medium text-muted-foreground">{m.month}</span>
              </li>
            )
          })}
        </ul>
      </figure>
    </Card>
  )
}
