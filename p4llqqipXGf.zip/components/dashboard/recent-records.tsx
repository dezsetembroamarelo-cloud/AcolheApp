import { FileText } from 'lucide-react'
import { Card } from '@/components/shared/compliance-badges'

const records = [
  { patient: 'Bruno Carvalho', when: 'Ontem, 13:00', summary: 'Evolução na exposição gradual; manter registro de pensamentos.' },
  { patient: 'Letícia Nunes', when: 'Há 2 dias', summary: 'Elaboração do luto; foco em rede de apoio na próxima sessão.' },
  { patient: 'Mariana Alves', when: 'Há 8 dias', summary: 'Ansiedade no trabalho; introduzida respiração diafragmática.' },
]

export function RecentRecords() {
  return (
    <Card>
      <h2 className="border-b border-border px-5 py-4 font-semibold">Prontuários recentes</h2>
      <ul className="divide-y divide-border">
        {records.map((r) => (
          <li key={r.patient} className="flex gap-3 px-5 py-4">
            <span className="flex size-9 shrink-0 items-center justify-center rounded-xl bg-secondary text-primary">
              <FileText className="size-4" aria-hidden />
            </span>
            <div className="min-w-0">
              <p className="text-sm font-medium">
                {r.patient} <span className="font-normal text-muted-foreground">· {r.when}</span>
              </p>
              <p className="mt-0.5 line-clamp-2 text-sm text-muted-foreground">{r.summary}</p>
            </div>
          </li>
        ))}
      </ul>
    </Card>
  )
}
