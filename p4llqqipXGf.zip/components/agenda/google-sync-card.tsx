import { ArrowLeftRight, CalendarDays, CheckCircle2 } from 'lucide-react'
import { appointments } from '@/lib/data'
import { Card } from '@/components/shared/compliance-badges'

export function GoogleSyncCard() {
  const synced = appointments.filter((a) => a.googleSynced).length
  const pending = appointments.length - synced

  return (
    <div className="flex flex-col gap-6">
      <Card className="p-5">
        <div className="flex items-center gap-3">
          <span className="flex size-10 items-center justify-center rounded-xl bg-secondary text-primary">
            <CalendarDays className="size-5" aria-hidden />
          </span>
          <div>
            <h2 className="font-semibold">Google Calendar</h2>
            <p className="flex items-center gap-1 text-xs text-muted-foreground">
              <ArrowLeftRight className="size-3" aria-hidden />
              Sincronização bidirecional
            </p>
          </div>
        </div>
        <dl className="mt-4 grid grid-cols-2 gap-3 text-center">
          <div className="rounded-xl bg-muted/60 p-3">
            <dt className="text-xs text-muted-foreground">Sincronizadas</dt>
            <dd className="text-lg font-bold">{synced}</dd>
          </div>
          <div className="rounded-xl bg-muted/60 p-3">
            <dt className="text-xs text-muted-foreground">Pendentes</dt>
            <dd className="text-lg font-bold">{pending}</dd>
          </div>
        </dl>
        <a
          href="/api/integrations/google/connect"
          className="mt-4 inline-flex h-10 w-full items-center justify-center rounded-xl bg-primary text-sm font-semibold text-primary-foreground shadow-sm transition hover:brightness-110"
        >
          Conectar conta Google
        </a>
        <ul className="mt-4 flex flex-col gap-2 text-xs text-muted-foreground">
          {['Sessões criadas aqui aparecem no Google', 'Eventos do Google bloqueiam horários', 'Nome do paciente nunca é enviado'].map((t) => (
            <li key={t} className="flex items-center gap-2">
              <CheckCircle2 className="size-3.5 text-success" aria-hidden />
              {t}
            </li>
          ))}
        </ul>
      </Card>

      <Card className="p-5">
        <h2 className="text-sm font-semibold">Legenda</h2>
        <ul className="mt-3 flex flex-col gap-2 text-sm">
          <li className="flex items-center gap-2"><span className="size-3 rounded-sm bg-primary" aria-hidden />Confirmada</li>
          <li className="flex items-center gap-2"><span className="size-3 rounded-sm bg-warning" aria-hidden />Aguardando confirmação</li>
          <li className="flex items-center gap-2"><span className="size-3 rounded-sm bg-muted-foreground/40" aria-hidden />Cancelada</li>
        </ul>
      </Card>
    </div>
  )
}
