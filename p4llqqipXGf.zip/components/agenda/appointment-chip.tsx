import Link from 'next/link'
import { RefreshCw, Video } from 'lucide-react'
import { cn } from '@/lib/utils'
import { getPatient, type Appointment } from '@/lib/data'

export function AppointmentChip({ appointment: a }: { appointment: Appointment }) {
  const patient = getPatient(a.patientId)
  return (
    <Link
      href={`/atendimento?paciente=${a.patientId}`}
      className={cn(
        'flex h-full flex-col overflow-hidden rounded-lg border-l-4 px-2 py-1 text-xs transition hover:shadow-md',
        a.status === 'cancelado' && 'border-muted-foreground/40 bg-muted text-muted-foreground line-through',
        a.status === 'pendente' && 'border-warning bg-warning/10 text-foreground',
        a.status === 'confirmado' && 'border-primary bg-secondary text-secondary-foreground',
      )}
    >
      <span className="truncate font-semibold">{patient?.name}</span>
      <span className="flex items-center gap-1 opacity-80">
        {a.start}–{a.end}
        {a.modality === 'online' && <Video className="size-3" aria-label="Online" />}
        {a.googleSynced && <RefreshCw className="size-3" aria-label="Sincronizado com Google Calendar" />}
      </span>
    </Link>
  )
}
