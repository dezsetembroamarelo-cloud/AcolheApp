'use client'

import { useMemo, useState } from 'react'
import { ChevronLeft, ChevronRight, Plus } from 'lucide-react'
import { cn } from '@/lib/utils'
import { appointments, getPatient, type Appointment } from '@/lib/data'
import { Card } from '@/components/shared/compliance-badges'
import { GoogleSyncCard } from './google-sync-card'
import { AppointmentChip } from './appointment-chip'

type View = 'dia' | 'semana' | 'mes'
const HOURS = Array.from({ length: 13 }, (_, i) => i + 7)
const WEEKDAYS = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb']
const HOUR_HEIGHT = 64

const iso = (d: Date) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`
const addDays = (d: Date, n: number) => {
  const c = new Date(d)
  c.setDate(c.getDate() + n)
  return c
}
const startOfWeek = (d: Date) => addDays(d, -d.getDay())
const toMinutes = (t: string) => {
  const [h, m] = t.split(':').map(Number)
  return h * 60 + m
}

export function CalendarView() {
  const [view, setView] = useState<View>('semana')
  const [cursor, setCursor] = useState(() => new Date())
  const todayIso = iso(new Date())

  const byDate = useMemo(() => {
    const map = new Map<string, Appointment[]>()
    for (const a of appointments) map.set(a.date, [...(map.get(a.date) ?? []), a])
    return map
  }, [])

  const days = useMemo(() => {
    if (view === 'dia') return [cursor]
    if (view === 'semana') return Array.from({ length: 7 }, (_, i) => addDays(startOfWeek(cursor), i))
    const first = new Date(cursor.getFullYear(), cursor.getMonth(), 1)
    return Array.from({ length: 42 }, (_, i) => addDays(startOfWeek(first), i))
  }, [view, cursor])

  function move(dir: -1 | 1) {
    if (view === 'dia') setCursor((c) => addDays(c, dir))
    else if (view === 'semana') setCursor((c) => addDays(c, dir * 7))
    else setCursor((c) => new Date(c.getFullYear(), c.getMonth() + dir, 1))
  }

  const title =
    view === 'dia'
      ? cursor.toLocaleDateString('pt-BR', { weekday: 'long', day: 'numeric', month: 'long' })
      : view === 'semana'
        ? `${days[0].toLocaleDateString('pt-BR', { day: 'numeric', month: 'short' })} – ${days[6].toLocaleDateString('pt-BR', { day: 'numeric', month: 'short', year: 'numeric' })}`
        : cursor.toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' })

  return (
    <div className="mx-auto max-w-7xl">
      <div className="mb-6 flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Agenda</h1>
          <p className="mt-1 text-sm text-muted-foreground">Gerencie suas sessões e sincronize com o Google Calendar.</p>
        </div>
        <button
          type="button"
          className="inline-flex h-10 items-center gap-2 self-start rounded-xl bg-primary px-4 text-sm font-semibold text-primary-foreground shadow-sm transition hover:brightness-110"
        >
          <Plus className="size-4" aria-hidden />
          Nova sessão
        </button>
      </div>

      <div className="grid gap-6 xl:grid-cols-[1fr_300px]">
        <Card className="overflow-hidden">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-border px-4 py-3">
            <div className="flex items-center gap-2">
              <button type="button" onClick={() => setCursor(new Date())} className="h-9 rounded-xl border border-border px-3 text-sm font-medium hover:bg-muted">
                Hoje
              </button>
              <div className="flex">
                <button type="button" onClick={() => move(-1)} className="flex size-9 items-center justify-center rounded-l-xl border border-border hover:bg-muted" aria-label="Anterior">
                  <ChevronLeft className="size-4" aria-hidden />
                </button>
                <button type="button" onClick={() => move(1)} className="-ml-px flex size-9 items-center justify-center rounded-r-xl border border-border hover:bg-muted" aria-label="Próximo">
                  <ChevronRight className="size-4" aria-hidden />
                </button>
              </div>
              <h2 className="ml-1 text-base font-semibold capitalize">{title}</h2>
            </div>
            <div role="tablist" aria-label="Visualização" className="flex rounded-xl bg-muted p-1">
              {(['dia', 'semana', 'mes'] as const).map((v) => (
                <button
                  key={v}
                  role="tab"
                  type="button"
                  aria-selected={view === v}
                  onClick={() => setView(v)}
                  className={cn(
                    'h-8 rounded-lg px-3 text-sm font-medium capitalize transition',
                    view === v ? 'bg-card text-foreground shadow-sm' : 'text-muted-foreground hover:text-foreground',
                  )}
                >
                  {v === 'mes' ? 'Mês' : v}
                </button>
              ))}
            </div>
          </div>

          {view === 'mes' ? (
            <MonthGrid days={days} month={cursor.getMonth()} byDate={byDate} todayIso={todayIso} onPick={(d) => { setCursor(d); setView('dia') }} />
          ) : (
            <TimeGrid days={days} byDate={byDate} todayIso={todayIso} />
          )}
        </Card>

        <GoogleSyncCard />
      </div>
    </div>
  )
}

function TimeGrid({ days, byDate, todayIso }: { days: Date[]; byDate: Map<string, Appointment[]>; todayIso: string }) {
  return (
    <div className="overflow-x-auto">
      <div className={days.length > 1 ? 'min-w-[720px]' : undefined}>
        <div className="grid border-b border-border" style={{ gridTemplateColumns: `56px repeat(${days.length}, 1fr)` }}>
          <div />
          {days.map((d) => {
            const isToday = iso(d) === todayIso
            return (
              <div key={iso(d)} className="flex flex-col items-center gap-0.5 py-3">
                <span className="text-xs font-medium uppercase text-muted-foreground">{WEEKDAYS[d.getDay()]}</span>
                <span className={cn('flex size-8 items-center justify-center rounded-full text-sm font-semibold', isToday && 'bg-primary text-primary-foreground')}>
                  {d.getDate()}
                </span>
              </div>
            )
          })}
        </div>
        <div className="grid max-h-[640px] overflow-y-auto" style={{ gridTemplateColumns: `56px repeat(${days.length}, 1fr)` }}>
          <div>
            {HOURS.map((h) => (
              <div key={h} className="pr-2 text-right text-[11px] text-muted-foreground" style={{ height: HOUR_HEIGHT }}>
                {String(h).padStart(2, '0')}:00
              </div>
            ))}
          </div>
          {days.map((d) => (
            <div key={iso(d)} className={cn('relative border-l border-border', iso(d) === todayIso && 'bg-secondary/30')}>
              {HOURS.map((h) => (
                <div key={h} className="border-b border-dashed border-border" style={{ height: HOUR_HEIGHT }} />
              ))}
              {(byDate.get(iso(d)) ?? []).map((a) => {
                const top = ((toMinutes(a.start) - HOURS[0] * 60) / 60) * HOUR_HEIGHT
                const height = ((toMinutes(a.end) - toMinutes(a.start)) / 60) * HOUR_HEIGHT
                return (
                  <div key={a.id} className="absolute inset-x-1" style={{ top, height }}>
                    <AppointmentChip appointment={a} />
                  </div>
                )
              })}
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

function MonthGrid({
  days,
  month,
  byDate,
  todayIso,
  onPick,
}: {
  days: Date[]
  month: number
  byDate: Map<string, Appointment[]>
  todayIso: string
  onPick: (d: Date) => void
}) {
  return (
    <div>
      <div className="grid grid-cols-7 border-b border-border">
        {WEEKDAYS.map((w) => (
          <div key={w} className="py-2 text-center text-xs font-medium uppercase text-muted-foreground">
            {w}
          </div>
        ))}
      </div>
      <div className="grid grid-cols-7">
        {days.map((d) => {
          const list = byDate.get(iso(d)) ?? []
          const isToday = iso(d) === todayIso
          return (
            <button
              key={iso(d)}
              type="button"
              onClick={() => onPick(d)}
              className={cn(
                'flex min-h-24 flex-col gap-1 border-b border-r border-border p-2 text-left transition hover:bg-muted/60',
                d.getMonth() !== month && 'bg-muted/30 text-muted-foreground',
              )}
            >
              <span className={cn('flex size-6 items-center justify-center rounded-full text-xs font-semibold', isToday && 'bg-primary text-primary-foreground')}>
                {d.getDate()}
              </span>
              {list.slice(0, 2).map((a) => (
                <span key={a.id} className={cn('truncate rounded-md px-1.5 py-0.5 text-[11px] font-medium', a.status === 'cancelado' ? 'bg-muted text-muted-foreground line-through' : 'bg-secondary text-secondary-foreground')}>
                  {a.start} {getPatient(a.patientId)?.name.split(' ')[0]}
                </span>
              ))}
              {list.length > 2 && <span className="text-[11px] text-muted-foreground">+{list.length - 2} mais</span>}
            </button>
          )
        })}
      </div>
    </div>
  )
}
